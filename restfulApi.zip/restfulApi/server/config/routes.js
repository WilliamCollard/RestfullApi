console.log("inside of routes.js");

const Tasks = require("../controllers/tasks");

module.exports = function(app){
    app.get("/tasks", Tasks.getAll);
    app.get("/tasks", Tasks.getById);
    app.post("/tasks", Tasks.create);
    app.put("/tasks/:id", Tasks.update);
    app.delete("/tasks/:id", Tasks.delete);
  }
  