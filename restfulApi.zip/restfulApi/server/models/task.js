console.log("inside of task.js");

const mongoose = require("mongoose");

const TaskSchema = new mongoose.Schema({
  title: {type: String, required: [true, "Tasks must have a title."]},
  description: {type: String, required: [true, "Tasks must have a description."]},
  completed: {type: Boolean, default: false },
  
},{timestamps: true});

mongoose.model('Task', TaskSchema);

module.exports = TaskSchema;

// {timestamps: true})